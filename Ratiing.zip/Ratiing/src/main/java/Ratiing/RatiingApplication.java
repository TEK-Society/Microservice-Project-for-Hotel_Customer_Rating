package Ratiing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RatiingApplication {

	public static void main(String[] args) {
		SpringApplication.run(RatiingApplication.class, args);
	}

}
